# django_english_dictionary

English dictionary with django framework. A code along from tomitokko's django tutorial on youtube.

Link to site https://dictionary-english.herokuapp.com/
